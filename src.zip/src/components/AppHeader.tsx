import { View, Text, TouchableOpacity, StyleSheet, Modal } from 'react-native'
import { useRef, useState, type ReactNode } from 'react'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useNavigation } from '@react-navigation/native'
import type { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { useClub } from '../lib/ClubContext'
import { UserAvatarBtn } from './UserAvatar'
import { useSkin } from '../skins'
import { Icon } from './Icon'
import type { RootStackParamList } from '../navigation/types'

type Nav = NativeStackNavigationProp<RootStackParamList>

export function AppHeader({ myName, showSettings = false, rightExtra }: {
  myName: string | null
  showSettings?: boolean
  rightExtra?: ReactNode
}) {
  const insets = useSafeAreaInsets()
  const { palette } = useSkin()
  const nav = useNavigation<Nav>()
  const { activeClub: club, myClubs, setActiveClub } = useClub()
  const badgeRef = useRef<View>(null)
  const [menu, setMenu] = useState<{ x: number; y: number; w: number } | null>(null)
  const isLightHeader = palette.headerBg === '#ffffff'
  const pillBg = isLightHeader ? palette.greenLight : 'rgba(255,255,255,0.17)'
  const pillBorder = isLightHeader ? palette.border : 'rgba(255,255,255,0.28)'
  const pillText = palette.headerText

  void myName
  void showSettings
  void rightExtra

  function openMenu() {
    badgeRef.current?.measureInWindow((x, y, w, h) => setMenu({ x, y: y + h + 4, w: Math.max(w, 180) }))
  }

  return (
    <View style={[s.header, { paddingTop: insets.top + 10, backgroundColor: palette.headerBg }]}> 
      {club ? (
        <View ref={badgeRef} collapsable={false} style={s.clubWrap}>
          <TouchableOpacity activeOpacity={0.84} onPress={openMenu} style={[s.clubPill, { backgroundColor: pillBg, borderColor: pillBorder }]}> 
            <Text style={s.clubIcon}>⛳</Text>
            <Text style={[s.clubText, { color: pillText }]} numberOfLines={1}>{club.name}</Text>
            <Text style={[s.clubArrow, { color: pillText }]}>⌄</Text>
          </TouchableOpacity>
        </View>
      ) : <View style={s.clubWrap} />}

      <View style={s.headerActions}>
        <TouchableOpacity activeOpacity={0.84} onPress={() => nav.navigate('NoticePrototype')} style={[s.circleButton, { backgroundColor: pillBg, borderColor: pillBorder }]}> 
          <Text style={s.bellText}>🔔</Text>
          <View style={[s.badge, { backgroundColor: palette.danger }]}> 
            <Text style={s.badgeText}>3</Text>
          </View>
        </TouchableOpacity>
        <UserAvatarBtn size={38} borderColor="rgba(255,255,255,0.48)" />
      </View>

      {menu && (
        <Modal transparent animationType="fade" onRequestClose={() => setMenu(null)}>
          <TouchableOpacity style={s.overlay} activeOpacity={1} onPress={() => setMenu(null)}>
            <View style={[s.menu, { left: menu.x, top: menu.y, minWidth: menu.w, backgroundColor: palette.card, borderColor: palette.border }]}> 
              {myClubs.map((c) => {
                const active = c.id === club?.id
                return (
                  <TouchableOpacity
                    key={c.id}
                    style={[s.menuItem, active && { backgroundColor: palette.greenLight }]}
                    onPress={() => { setActiveClub(c); setMenu(null) }}
                  >
                    <Text style={[s.menuText, { color: active ? palette.green : palette.text, fontWeight: active ? '800' : '500' }]} numberOfLines={1}>⛳ {c.name}</Text>
                    {active && <Icon name="check" size={14} color={palette.green} strokeWidth={2.4} />}
                  </TouchableOpacity>
                )
              })}
            </View>
          </TouchableOpacity>
        </Modal>
      )}
    </View>
  )
}

const s = StyleSheet.create({
  header: {
    paddingBottom: 10,
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  clubWrap: { flex: 1, minWidth: 0, paddingRight: 12 },
  clubPill: {
    alignSelf: 'flex-start',
    maxWidth: 220,
    minHeight: 38,
    borderRadius: 19,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    borderWidth: 1,
  },
  clubIcon: { fontSize: 15, lineHeight: 18 },
  clubText: { flexShrink: 1, fontSize: 13, lineHeight: 17, fontWeight: '900', letterSpacing: -0.3 },
  clubArrow: { fontSize: 14, lineHeight: 17, fontWeight: '900', marginTop: -2 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  circleButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  bellText: { fontSize: 16, lineHeight: 18 },
  badge: {
    position: 'absolute',
    right: -1,
    top: -2,
    minWidth: 15,
    height: 15,
    borderRadius: 7.5,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  badgeText: { color: '#fff', fontSize: 9, lineHeight: 11, fontWeight: '900' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.15)' },
  menu: {
    position: 'absolute', borderRadius: 12, paddingVertical: 6, maxWidth: 260, borderWidth: 1,
    shadowColor: '#000', shadowOpacity: 0.18, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 8,
  },
  menuItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingHorizontal: 14, paddingVertical: 11 },
  menuText: { fontSize: 14 },
})
