# NEXT - Home Redesign v3.0 Phase 2

## 다음 확인 필요
- 실제 기기/Expo에서 Hero 내부 상단 버튼 위치 확인
- 작은 화면에서 클럽명이 길 때 버튼 폭과 말줄임 확인
- Hero 본문 D-Day/골프장명과 상단 버튼 겹침 여부 확인

## 다음 개발 후보
1. Hero 내부 Typography 최종 정리
2. Today's AI 카드와 Hero 간 여백 조정
3. Quick Menu Premium 카드 간격 최종 조정
4. 관리자용 마지막 Hero `새 라운딩 등록` 카드 디자인 개선

## 주의
- DB 변경 없음
- Upcoming Round 카드는 Home에 복구하지 않음
- Hero는 오늘의 라운드 준비 Dashboard 역할을 유지
