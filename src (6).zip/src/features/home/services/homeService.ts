import {
  createEmptyHomeDashboard,
  mapHomeDashboard,
} from "../mappers/homeMapper";
import type {
  HomeDashboard,
  HomeHeroRound,
  HomeUpcomingRound,
} from "../types/home";
import { getHomeAICaddiePreview } from "../../caddie/services/caddieService";
import {
  buildWeatherByCourseId,
  fetchWeatherByScheduleId,
  getHomeDashboardRawData,
  type HomeDashboardRawData,
} from "../api/homeRepository";
import {
  formatRecommendedDepartureTime,
  formatTravelMinutes,
  getDrivingTravelTimeMinutes,
} from "../../../lib/travelTime";

type HomeCoordinate = {
  latitude?: number | null;
  longitude?: number | null;
};

export type HomeDashboardBaseResult = {
  dashboard: HomeDashboard;
  raw: HomeDashboardRawData | null;
};

type TravelRoundUpdate = Pick<
  HomeHeroRound,
  "id" | "routeTimeText" | "departureTimeText"
>;

type AiCaddieUpdate = Partial<HomeDashboard["aiCaddie"]>;

export async function getHomeDashboardBase(
  clubId?: string | null,
  userName?: string | null,
  userId?: string | null,
  options: { forceRefresh?: boolean } = {},
): Promise<HomeDashboardBaseResult> {
  if (!clubId) return { dashboard: createEmptyHomeDashboard(), raw: null };

  const raw = await getHomeDashboardRawData(clubId, options);
  return {
    dashboard: mapHomeDashboard(raw, userName, userId),
    raw,
  };
}

export async function getHomeWeatherDashboard(
  raw: HomeDashboardRawData,
  userName?: string | null,
  userId?: string | null,
): Promise<HomeDashboard> {
  const weatherByScheduleId = await fetchWeatherByScheduleId(
    raw.schedules,
    raw.courses,
  );
  const weatherRaw: HomeDashboardRawData = {
    ...raw,
    weatherByScheduleId,
    weatherByCourseId: buildWeatherByCourseId(
      raw.schedules,
      weatherByScheduleId,
    ),
  };

  return mapHomeDashboard(weatherRaw, userName, userId);
}

export function mergeHomeWeather(
  current: HomeDashboard,
  weatherDashboard: HomeDashboard,
): HomeDashboard {
  const weatherRoundById = new Map(
    weatherDashboard.hero.rounds.map((round) => [round.id, round]),
  );
  const rounds = current.hero.rounds.map((round) => {
    const weatherRound = weatherRoundById.get(round.id);
    if (!weatherRound) return round;
    return {
      ...round,
      weatherText: weatherRound.weatherText,
      temperature: weatherRound.temperature,
      windText: weatherRound.windText,
    };
  });

  const firstRound = rounds[0];
  const upcomingRound: HomeUpcomingRound | null =
    current.upcomingRound && firstRound?.id === current.upcomingRound.id
      ? {
          ...current.upcomingRound,
          weatherText: firstRound.weatherText,
          temperature: firstRound.temperature,
          windText: firstRound.windText,
        }
      : current.upcomingRound;

  return {
    ...current,
    hero: {
      ...current.hero,
      weatherText: firstRound?.weatherText ?? current.hero.weatherText,
      temperature: firstRound?.temperature ?? current.hero.temperature,
      rounds,
    },
    upcomingRound,
  };
}

export async function getHomeTravelUpdates(
  raw: HomeDashboardRawData,
  dashboard: HomeDashboard,
  home?: HomeCoordinate | null,
  departureBufferMinutes = 40,
): Promise<TravelRoundUpdate[]> {
  if (typeof home?.latitude !== "number" || typeof home.longitude !== "number")
    return [];

  const roundById = new Map(
    dashboard.hero.rounds.map((round) => [round.id, round]),
  );
  const courseById = new Map(raw.courses.map((course) => [course.id, course]));

  return Promise.all(
    raw.schedules.map(async (schedule) => {
      const course = schedule.course_id
        ? courseById.get(schedule.course_id)
        : undefined;
      const minutes = await getDrivingTravelTimeMinutes(home, {
        latitude: course?.latitude,
        longitude: course?.longitude,
      }).catch(() => null);

      if (!minutes) {
        return {
          id: schedule.id,
          routeTimeText: "이동시간 준비중",
          departureTimeText: "출발 추천 준비중",
        };
      }

      return {
        id: schedule.id,
        routeTimeText: formatTravelMinutes(minutes),
        departureTimeText: formatRecommendedDepartureTime(
          schedule.round_date,
          roundById.get(schedule.id)?.teeTime ?? schedule.tee_time ?? undefined,
          minutes,
          departureBufferMinutes,
        ),
      };
    }),
  );
}

export function mergeHomeTravel(
  current: HomeDashboard,
  updates: TravelRoundUpdate[],
): HomeDashboard {
  if (!updates.length) return current;
  const updateById = new Map(updates.map((update) => [update.id, update]));
  const rounds = current.hero.rounds.map((round) => {
    const update = updateById.get(round.id);
    return update ? { ...round, ...update } : round;
  });

  return {
    ...current,
    hero: {
      ...current.hero,
      rounds,
    },
  };
}

export async function getHomeAiCaddieUpdate(
  dashboard: HomeDashboard,
  userId?: string | null,
): Promise<AiCaddieUpdate | null> {
  const upcomingRound = dashboard.upcomingRound;
  const aiPreview = await getHomeAICaddiePreview({
    userId,
    courseId: upcomingRound?.courseId,
    layoutId: upcomingRound?.layoutId,
    holeNo: 1,
    courseName: upcomingRound?.courseName,
    teeTime: upcomingRound?.teeTime,
    dday: upcomingRound?.dday,
    fallbackAverageScore: dashboard.stats.averageScore,
  });

  if (!aiPreview) return null;

  return {
    title: aiPreview.title,
    message: aiPreview.message,
    primaryChip: aiPreview.primaryChip,
    secondaryChip: aiPreview.secondaryChip,
    hasLiveAdvice: aiPreview.hasLiveAdvice,
    recommendedClub: aiPreview.recommendedClub,
    riskLabel: aiPreview.riskLabel,
  };
}

export function mergeHomeAiCaddie(
  current: HomeDashboard,
  update: AiCaddieUpdate | null,
): HomeDashboard {
  if (!update) return current;
  return {
    ...current,
    aiCaddie: {
      ...current.aiCaddie,
      ...update,
    },
  };
}

// 기존 호출부와의 호환성을 유지한다. 신규 홈 hook은 getHomeDashboardBase와 보강 함수를 사용한다.
export async function getHomeDashboard(
  clubId?: string | null,
  userName?: string | null,
  userId?: string | null,
  home?: HomeCoordinate | null,
  departureBufferMinutes = 40,
): Promise<HomeDashboard> {
  const { dashboard, raw } = await getHomeDashboardBase(
    clubId,
    userName,
    userId,
  );
  if (!raw) return dashboard;

  const [weatherDashboard, travelUpdates, aiUpdate] = await Promise.all([
    getHomeWeatherDashboard(raw, userName, userId).catch(() => null),
    getHomeTravelUpdates(raw, dashboard, home, departureBufferMinutes).catch(
      () => [],
    ),
    getHomeAiCaddieUpdate(dashboard, userId).catch(() => null),
  ]);

  let nextDashboard = dashboard;
  if (weatherDashboard)
    nextDashboard = mergeHomeWeather(nextDashboard, weatherDashboard);
  nextDashboard = mergeHomeTravel(nextDashboard, travelUpdates);
  return mergeHomeAiCaddie(nextDashboard, aiUpdate);
}
