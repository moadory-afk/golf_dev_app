import { Modal, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { useRef, useState } from 'react'
import { useNavigation } from '@react-navigation/native'
import type { NativeStackNavigationProp } from '@react-navigation/native-stack'

import { useClub } from '../lib/ClubContext'
import { useSkin } from '../skins'
import type { RootStackParamList } from '../navigation/types'
import { UserAvatarBtn } from './UserAvatar'


type Nav = NativeStackNavigationProp<RootStackParamList>

type TopActionButtonsProps = {
  topInset?: number
  floating?: boolean
}

export function TopActionButtons({ topInset = 0, floating = false }: TopActionButtonsProps) {
  const { palette } = useSkin()
  const nav = useNavigation<Nav>()
  const { activeClub: club, myClubs, setActiveClub } = useClub()
  const clubRef = useRef<View>(null)
  const [menu, setMenu] = useState<{ x: number; y: number; w: number } | null>(null)

  function openClubMenu() {
    clubRef.current?.measureInWindow((x, y, w, h) => setMenu({ x, y: y + h + 6, w: Math.max(w, 190) }))
  }

  return (
    <View style={[styles.row, floating && styles.floating, floating && { top: topInset + 10 }]} pointerEvents="box-none">
      <View ref={clubRef} collapsable={false} style={{ flexShrink: 1 }}>
        <TouchableOpacity activeOpacity={0.84} onPress={openClubMenu} style={styles.clubPill}>
          <Text style={styles.clubIcon}>⛳</Text>
          <Text style={styles.clubText} numberOfLines={1}>{club?.name || 'GogoPar Club'}</Text>
          <Text style={styles.clubArrow}>⌄</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity activeOpacity={0.84} onPress={() => nav.navigate('NoticePrototype')} style={styles.circleButton}>
          <Text style={styles.bellText}>🔔</Text>
          <View style={[styles.badge, { backgroundColor: palette.danger }]}> 
            <Text style={styles.badgeText}>3</Text>
          </View>
        </TouchableOpacity>
        <UserAvatarBtn size={40} />
      </View>

      {menu && (
        <Modal transparent animationType="fade" onRequestClose={() => setMenu(null)}>
          <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setMenu(null)}>
            <View style={[styles.menu, { left: menu.x, top: menu.y, minWidth: menu.w, backgroundColor: palette.card, borderColor: palette.border }]}> 
              {myClubs.length === 0 ? (
                <Text style={[styles.menuEmpty, { color: palette.muted }]}>참여 중인 클럽이 없습니다</Text>
              ) : myClubs.map((item) => {
                const selected = item.id === club?.id
                return (
                  <TouchableOpacity
                    key={item.id}
                    style={[styles.menuItem, selected && { backgroundColor: palette.greenLight }]}
                    onPress={() => { setActiveClub(item); setMenu(null) }}
                    activeOpacity={0.8}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.menuText, { color: selected ? palette.green : palette.text, fontWeight: selected ? '800' : '600' }]} numberOfLines={1}>⛳ {item.name}</Text>
                      <Text style={[styles.menuSub, { color: palette.muted }]} numberOfLines={1}>{item.role === 'admin' ? '관리자' : '회원'}</Text>
                    </View>
                    {selected && <Text style={[styles.check, { color: palette.green }]}>✓</Text>}
                  </TouchableOpacity>
                )
              })}
            </View>
          </TouchableOpacity>
        </Modal>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12, paddingHorizontal: 20 },
  floating: { position: 'absolute', left: 0, right: 0, zIndex: 20 },
  clubPill: {
    height: 40,
    maxWidth: 210,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.9)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  clubIcon: { fontSize: 15 },
  clubText: { color: '#142019', fontSize: 13, fontWeight: '800', flexShrink: 1 },
  clubArrow: { color: '#142019', fontSize: 16, fontWeight: '800', marginTop: -3 },
  actions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  circleButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.9)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  bellText: { fontSize: 17 },
  badge: { position: 'absolute', top: 6, right: 5, minWidth: 15, height: 15, borderRadius: 8, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  badgeText: { color: '#fff', fontSize: 9, fontWeight: '900' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.16)' },
  menu: { position: 'absolute', borderRadius: 16, paddingVertical: 6, maxWidth: 280, borderWidth: 1, shadowColor: '#000', shadowOpacity: 0.18, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 8 },
  menuItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingHorizontal: 14, paddingVertical: 11 },
  menuText: { fontSize: 14 },
  menuSub: { fontSize: 11, marginTop: 2 },
  menuEmpty: { paddingHorizontal: 14, paddingVertical: 12, fontSize: 13 },
  check: { fontWeight: '900', fontSize: 15 },
})
