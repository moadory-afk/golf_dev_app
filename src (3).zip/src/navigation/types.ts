import type { NativeStackScreenProps } from '@react-navigation/native-stack'
import type { NavigatorScreenParams } from '@react-navigation/native'
import type { SettlementConfig } from '../lib/store'

export type MainTabParamList = {
  Home: undefined
  Club: { openManageMenu?: boolean; openCreateClub?: boolean } | undefined
  History: undefined
}

export type RootStackParamList = {
  Login: undefined
  SignUpRoute: undefined
  Main: NavigatorScreenParams<MainTabParamList> | undefined
  Profile: undefined
  HeroLab: undefined
  FeePrototype: { returnToManageMenu?: boolean } | undefined
  RoundSchedulePrototype: { returnToManageMenu?: boolean; openCreate?: boolean; editScheduleId?: string; modalOnly?: boolean } | undefined
  CaddieBook: { courseId?: string | null; layoutId?: string | null; courseName?: string | null; layoutName?: string | null; scheduleId?: string | null } | undefined
  FeeMemberPrototype: { clubId: string; memberUserId: string; memberName: string; statusId: string }
  TreasuryLedgerPrototype: undefined
  TreasuryEntryPrototype: {
    kind: 'income' | 'expense'
    entry?: {
      id: string
      type: 'income' | 'expense'
      title: string
      amount: number
      entryDate: string
      memo: string
    }
  }
  NoticePrototype: { returnToManageMenu?: boolean } | undefined
  ScoreCapture: undefined
  Members: { clubId: string; returnToManageMenu?: boolean }
  RoundDetail: { id: string }
  RoundSetup: {
    ocrPlayers?: Array<{ name: string; strokes: number[] }>
    settlement?: SettlementConfig
  }
  PlayerSetup: {
    date: string
    courseName: string
    pars: number[]
    golfCourseId?: string
    ocrPlayers?: Array<{ name: string; strokes: number[] }>
    settlement?: SettlementConfig
  }
  ScoreEntry: {
    date: string
    courseName: string
    pars: number[]
    golfCourseId?: string
    players: Array<{ name: string; strokes: number[] }>
    editId?: string
    settlement?: SettlementConfig
    holeLabels?: string[]   // 예: ['밸리1',...,'밸리9','파인1',...,'파인9']
    photoUris?: string[]    // RoundSetup OCR 사진 → 라운드와 함께 저장
  }
  ScoreReview: {
    editId?: string
    courseName?: string
    date?: string
    pars?: number[]
    players?: Array<{ name: string; diffs: number[] }>
    photoUris?: string[]
    settlement?: SettlementConfig
    holeLabels?: string[]
  }
  Result: {
    editId?: string
    courseName?: string
    date?: string
    pars: number[]
    players: Array<{ name: string; strokes: number[] }>
    photoUris?: string[]
    settlement?: SettlementConfig
  },
  SignUp: undefined
}

export type RootStackProps<T extends keyof RootStackParamList> =
  NativeStackScreenProps<RootStackParamList, T>
